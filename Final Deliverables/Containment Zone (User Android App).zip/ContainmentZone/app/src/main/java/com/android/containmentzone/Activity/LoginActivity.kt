package com.android.containmentzone.Activity

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.android.containmentzone.Utility.MyLoader
import com.android.containmentzone.Utility.MySingleton.Companion.getInstance
import com.android.containmentzone.Utility.PrefManager
import com.android.containmentzone.databinding.ActivityLoginBinding
import com.android.volley.AuthFailureError
import com.android.volley.Response
import com.android.volley.VolleyError
import com.android.volley.toolbox.StringRequest
import com.neeloy.lib.data.storage.StorageUtility

class LoginActivity : AppCompatActivity() {
    var loginBinding: ActivityLoginBinding? = null
    @RequiresApi(api = Build.VERSION_CODES.Q)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loginBinding = ActivityLoginBinding.inflate(
            layoutInflater)
        setContentView(loginBinding!!.root)

        if (!isAllPermissionEnabled) requestPermission()

        loginBinding!!.alLogin.setOnClickListener { v: View? ->
            val email = loginBinding!!.alEmail.text.toString()
            val password = loginBinding!!.alPassword.text.toString()
            if (email.isEmpty()) Toast.makeText(this, "Enter Email", Toast.LENGTH_SHORT)
                .show() else if (password.isEmpty()) Toast.makeText(this,
                "Enter Password",
                Toast.LENGTH_SHORT).show() else _login(email, password)
        }
        loginBinding!!.alSignup.setOnClickListener { v: View? ->
            startActivity(Intent(this,
                RegistrationActivity::class.java))
        }
    }

    private fun _login(email: String, password: String) {
        val myLoader = MyLoader(this)
        myLoader.showIndeterminantLoader("Logging In")
        val stringRequest: StringRequest = object : StringRequest(Method.POST, PrefManager._LOGIN,
            Response.Listener { response: String ->
                Log.d("User Login : ", response)
                if (response == "Logged in successfully !") {
                    StorageUtility.setIntData(PrefManager.USER_LOGIN_STATUS, 1)
                    StorageUtility.setStringData(PrefManager.MAIL, email)
                    startActivity(Intent(this, MapsActivity::class.java))
                    Toast.makeText(this, response, Toast.LENGTH_SHORT).show()
                    finish()
                    myLoader.cancelIndeterminantLoader()
                } else {
                    Toast.makeText(this, response, Toast.LENGTH_SHORT).show()
                }
            },
            Response.ErrorListener { error: VolleyError ->
                myLoader.cancelIndeterminantLoader()
                Log.d("User Login : ", error.toString())
            }) {
            @Throws(AuthFailureError::class)
            override fun getParams(): Map<String, String>? {
                val map = HashMap<String, String>()
                map["email"] = email
                map["password"] = password
                return map
            }
        }
        getInstance(this)!!.addToRequestQueue(stringRequest, PrefManager._LOGIN)
    }

    @RequiresApi(api = Build.VERSION_CODES.Q)
    private fun requestPermission() {
        requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.READ_PHONE_STATE), 10)
    }

    private val isAllPermissionEnabled: Boolean
        private get() = if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_PHONE_STATE
            ) != PackageManager.PERMISSION_GRANTED
        ) false else true

}