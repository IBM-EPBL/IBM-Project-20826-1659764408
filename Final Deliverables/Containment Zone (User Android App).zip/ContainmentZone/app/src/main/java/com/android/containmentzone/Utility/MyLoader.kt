package com.android.containmentzone.Utility

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.View
import android.widget.TextView
import com.android.containmentzone.R

class MyLoader(var context: Context) {
    var dialog: Dialog? = null
    var loadingView: View? = null
    fun showIndeterminantLoader(text: String) {
        var text = text
        if (text.isEmpty()) text = "Loading"
        dialog = Dialog(context)
        loadingView = LayoutInflater.from(context).inflate(R.layout.dialog_loading, null)
        (loadingView!!.findViewById<View>(R.id.dialog_loader_text) as TextView).setText(text)
        dialog!!.setContentView(loadingView!!)
        dialog!!.setCancelable(false)
        dialog!!.show()
        dialog!!.window!!.setDimAmount(0.5f)
        dialog!!.window!!.setLayout(500, 500)
        dialog!!.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    }

    fun setText(text: String?) {
        (loadingView!!.findViewById<View>(R.id.dialog_loader_text) as TextView).setText(text)
    }

    fun cancelIndeterminantLoader() {
        if (dialog != null) {
            dialog!!.dismiss()
        }
    }
}