package com.android.containmentzone.Activity

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import androidx.appcompat.app.AppCompatActivity
import com.android.containmentzone.Utility.PrefManager
import com.android.containmentzone.databinding.ActivitySplashBinding
import com.neeloy.lib.data.storage.StorageUtility

class SplashActivity : AppCompatActivity() {
    var splashBinding: ActivitySplashBinding? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        splashBinding = ActivitySplashBinding.inflate(
            layoutInflater)
        setContentView(splashBinding!!.root)
        StorageUtility.initLibrary(this)
        Handler().postDelayed({
            if (StorageUtility.getIntData(PrefManager.USER_LOGIN_STATUS) == 1) startActivity(Intent(
                this,
                MapsActivity::class.java).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)) else startActivity(
                Intent(this,
                    LoginActivity::class.java).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
            finish()
        }, 1000)
    }
}