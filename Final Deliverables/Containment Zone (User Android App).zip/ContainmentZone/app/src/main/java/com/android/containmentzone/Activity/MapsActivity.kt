package com.android.containmentzone.Activity

import android.Manifest
import android.annotation.TargetApi
import android.app.PendingIntent
import android.content.Intent
import android.content.IntentSender
import android.content.pm.PackageManager
import android.content.pm.PackageManager.PERMISSION_GRANTED
import android.graphics.Color
import android.location.Location
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.adhanjadevelopers.geofencingdemo.createChannel
import com.android.containmentzone.R

import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.android.containmentzone.Utility.GeofenceBroadcastReceiver
import com.android.containmentzone.Utility.MyLoader
import com.android.containmentzone.Utility.MySingleton
import com.android.containmentzone.Utility.PrefManager
import com.android.containmentzone.databinding.ActivityMapsBinding
import com.android.volley.AuthFailureError
import com.android.volley.Response
import com.android.volley.VolleyError
import com.android.volley.toolbox.StringRequest
import com.google.android.gms.common.api.ResolvableApiException
import com.google.android.gms.location.*
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.CircleOptions
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.gms.tasks.CancellationToken
import com.google.android.gms.tasks.CancellationTokenSource
import com.google.android.gms.tasks.OnTokenCanceledListener
import com.google.android.gms.tasks.Task
import com.neeloy.lib.data.storage.StorageUtility
import java.util.*
import kotlin.collections.ArrayList

private const val TAG = "MapsActivity"
private lateinit var geoClient: GeofencingClient
private const val REQUEST_TURN_DEVICE_LOCATION_ON = 20
private const val REQUEST_FOREGROUND_AND_BACKGROUND_PERMISSION_RESULT_CODE = 3
private const val REQUEST_FOREGROUND_ONLY_PERMISSIONS_REQUEST_CODE = 4
private const val REQUEST_LOCATION_PERMISSION = 10

class MapsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var map: GoogleMap
    private lateinit var binding: ActivityMapsBinding
    private val geofenceList = ArrayList<Geofence>()
    var zonesList: MutableList<String> = java.util.ArrayList()
    private var fusedLocationClient: FusedLocationProviderClient? = null
    var isLocationAvailable = false
    var latitude: String? = null
    var longitude: String? = null

    private val gadgetQ = android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q

    private val geofenceIntent: PendingIntent by lazy {
        val intent = Intent(this, GeofenceBroadcastReceiver::class.java)
        PendingIntent.getBroadcast(this,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        createChannel(this)

        geoClient = LocationServices.getGeofencingClient(this)

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        binding.amLogout.setOnClickListener { v: View? ->
            StorageUtility.clearAllData()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }

        /*val latitude = 11.1348769
        val longitude = 77.2968646
        val radius = 3000f

        geofenceList.add(Geofence.Builder()
            .setRequestId("entry.key")
            .setCircularRegion(latitude, longitude, radius)
            .setExpirationDuration(Geofence.NEVER_EXPIRE)
            .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER)
            .build())*/

    }

    override fun onMapReady(googleMap: GoogleMap) {
        map = googleMap
        lastKnownLocation(map)
    }

    private fun isPermissionGranted(): Boolean {
        return ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_FINE_LOCATION
        ) === PackageManager.PERMISSION_GRANTED
    }

    private fun startLocation() {
        if (isPermissionGranted()) {
            if (ActivityCompat.checkSelfPermission(
                    this,
                    Manifest.permission.ACCESS_FINE_LOCATION
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                return
            }
            map.isMyLocationEnabled = true
        } else {
            ActivityCompat.requestPermissions(
                this, arrayOf<String>(Manifest.permission.ACCESS_FINE_LOCATION),
                REQUEST_LOCATION_PERMISSION
            )
        }
    }

    //specify the geofence to monitor and the initial trigger
    private fun seekGeofencing(): GeofencingRequest {
        return GeofencingRequest.Builder().apply {
            setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER)
            addGeofences(geofenceList)
        }.build()
    }

    //adding a geofence
    private fun addGeofence() {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }
        geoClient?.addGeofences(seekGeofencing(), geofenceIntent)?.run {
            addOnSuccessListener {
                Toast.makeText(this@MapsActivity, "Geofences added", Toast.LENGTH_SHORT).show()
            }
            addOnFailureListener {
                Toast.makeText(this@MapsActivity, "Failed to add geofences", Toast.LENGTH_SHORT)
                    .show()

            }
        }
    }

    //removing a geofence
    private fun removeGeofence() {
        geoClient?.removeGeofences(geofenceIntent)?.run {
            addOnSuccessListener {
                Toast.makeText(this@MapsActivity, "Geofences removed", Toast.LENGTH_SHORT).show()

            }
            addOnFailureListener {
                Toast.makeText(this@MapsActivity, "Failed to remove geofences", Toast.LENGTH_SHORT)
                    .show()
            }
        }
    }

    private fun examinePermisionAndinitiatGeofence() {
        if (authorizedLocation()) {
            validateGadgetAreaInitiateGeofence()
        } else {
            askLocationPermission()
        }
    }

    // check if background and foreground permissions are approved
    @TargetApi(29)
    private fun authorizedLocation(): Boolean {
        val formalizeForeground = (
                PERMISSION_GRANTED == ActivityCompat.checkSelfPermission(
                    this, Manifest.permission.ACCESS_FINE_LOCATION
                ))
        val formalizeBackground =
            if (gadgetQ) {
                PERMISSION_GRANTED == ActivityCompat.checkSelfPermission(
                    this, Manifest.permission.ACCESS_BACKGROUND_LOCATION
                )
            } else {
                true
            }
        return formalizeForeground && formalizeBackground
    }

    //requesting background and foreground permissions
    @TargetApi(29)
    private fun askLocationPermission() {
        if (authorizedLocation())
            return
        var grantingPermission = arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        val customResult = when {
            gadgetQ -> {
                grantingPermission += Manifest.permission.ACCESS_BACKGROUND_LOCATION
                REQUEST_FOREGROUND_AND_BACKGROUND_PERMISSION_RESULT_CODE
            }
            else -> REQUEST_FOREGROUND_ONLY_PERMISSIONS_REQUEST_CODE
        }
        Log.d(TAG, "askLocationPermission: ")
        ActivityCompat.requestPermissions(
            this,
            grantingPermission,
            customResult
        )

    }

    private fun validateGadgetAreaInitiateGeofence(resolve: Boolean = true) {
        val locationRequest = LocationRequest.create().apply {
            priority = LocationRequest.PRIORITY_LOW_POWER
        }
        val builder = LocationSettingsRequest.Builder().addLocationRequest(locationRequest)

        val client = LocationServices.getSettingsClient(this)
        val locationResponses =
            client.checkLocationSettings(builder.build())

        locationResponses.addOnFailureListener { exception ->
            if (exception is ResolvableApiException && resolve) {
                try {
                    exception.startResolutionForResult(
                        this,
                        REQUEST_TURN_DEVICE_LOCATION_ON
                    )
                } catch (sendEx: IntentSender.SendIntentException) {
                    Log.d(TAG, "Error geting location settings resolution: " + sendEx.message)
                }
            } else {
                Toast.makeText(this, "Enable your location", Toast.LENGTH_SHORT).show()
            }
        }
        locationResponses.addOnCompleteListener {
            if (it.isSuccessful) {
                _getzones()
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray,
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_LOCATION_PERMISSION) {
            if (grantResults.size > 0 && (grantResults[0] == PackageManager.PERMISSION_GRANTED))
                startLocation()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        validateGadgetAreaInitiateGeofence(false)
    }

    override fun onStart() {
        super.onStart()
        examinePermisionAndinitiatGeofence()
    }

    override fun onDestroy() {
        super.onDestroy()
        removeGeofence()
    }

    private fun _getzones() {
            val myLoader = MyLoader(this)
            myLoader.showIndeterminantLoader("Getting zones")
            val stringRequest: StringRequest =
                object : StringRequest(Method.GET, PrefManager._GET_ZONES,
                    Response.Listener { response: String ->
                        Log.e("Zones : ", response)
                        if (response != "Unable to get zones !") {
                            try {
                                val arrayList: java.util.ArrayList<String?> =
                                    java.util.ArrayList<String?>(Arrays.asList(*response.substring(1,
                                        response.length - 1).replace("{", "").replace("}", "")
                                        .split("', ").toTypedArray()))
                                Log.e("Array", arrayList[0] + arrayList[2])
                                zonesList.clear()
                                var i = 0
                                while (i < arrayList.size) {
                                    zonesList.add(arrayList[i]!!.substring(11))
                                    i = i + 2
                                }
                                geofenceList.clear()
                                for (i in zonesList.indices){
                                    val ll = zonesList[i].replace(" ", "").split(",").toTypedArray()
                                    Log.e("lat", ll[0])
                                    Log.e("lon", ll[1])
                                    geofenceList.add(Geofence.Builder()
                                        .setRequestId("entry.key")
                                        .setCircularRegion(ll.get(0).toDouble(), ll.get(1).toDouble(), 100f)
                                        .setExpirationDuration(Geofence.NEVER_EXPIRE)
                                        .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER)
                                        .build())
                                }
                                Log.e("GeoFence", geofenceList.toString())
                                addGeofence()
                                Toast.makeText(this, "Zones getted successfully", Toast.LENGTH_SHORT)
                                    .show()
                                myLoader.cancelIndeterminantLoader()
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                        } else {
                            Toast.makeText(this, response, Toast.LENGTH_SHORT).show()
                        }
                    },
                    Response.ErrorListener { error: VolleyError ->
                        myLoader.cancelIndeterminantLoader()
                        Log.d("Zones : ", error.toString())
                    }) {
                    @Throws(AuthFailureError::class)
                    override fun getParams(): Map<String, String>? {
                        return HashMap()
                    }
                }
            MySingleton.getInstance(this)!!.addToRequestQueue(stringRequest, PrefManager._GET_ZONES)
        }


    private fun lastKnownLocation(map: GoogleMap) {
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
            ) {
                return
            }
            fusedLocationClient!!.flushLocations()
            fusedLocationClient!!.locationAvailability.addOnCompleteListener { task: Task<LocationAvailability> ->
                Log.e("Loc Avail: ", "Req completed  ")
                if (task.isSuccessful) {
                    isLocationAvailable = task.result.isLocationAvailable
                    Log.e("Loc Avail: ", "Req success  " + task.result.toString())
                    if (isLocationAvailable) {
                        currentLocation(map)
                    } else {
                        currentLocation(map)
                        Toast.makeText(this, "Location not available", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

    private fun currentLocation(map: GoogleMap) {
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
            ) {
                return
            }
            fusedLocationClient!!.getCurrentLocation(LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY,
                object : CancellationToken() {
                    override fun onCanceledRequested(p0: OnTokenCanceledListener) = CancellationTokenSource().token

                    override fun isCancellationRequested() = false
                }).addOnFailureListener { e -> Log.e("Loc : ", "Req failed ---> " + e.message) }
                .addOnCompleteListener { task: Task<Location?> ->
                    Log.e("Loc : ", "Req completed ---> ")
                    if (task.isSuccessful) Log.e("Loc : ", "Req success ---> ")
                    if (task.isCanceled) Log.e("Loc : ", "Req cancel ---> ")
                    if (task.isComplete) Log.e("Loc : ", "Req complete ---> ")
                }
                .addOnSuccessListener { location: Location? ->
                    if (location != null) {
                        latitude = location.latitude.toString()
                        longitude = location.longitude.toString()
                        val latlng = LatLng(latitude!!.toDouble(), longitude!!.toDouble())
                        val circleOptions = CircleOptions()
                            .center(latlng)
                            .radius(20.0)
                            .fillColor(0x40ff0000)
                            .strokeColor(Color.BLUE)
                            .strokeWidth(2f)
                        val zoomLevel = 14f

                        map.moveCamera(CameraUpdateFactory.newLatLngZoom(latlng, zoomLevel))
                        map.addMarker(MarkerOptions().position(latlng))
                        map.addCircle(circleOptions)

                        startLocation()
                        Toast.makeText(this,
                            "Your current location : $latitude,$longitude",
                            Toast.LENGTH_SHORT).show()
                    } else {
                        Log.e("Loc : ", "Null")
                    }
                }
        }

}