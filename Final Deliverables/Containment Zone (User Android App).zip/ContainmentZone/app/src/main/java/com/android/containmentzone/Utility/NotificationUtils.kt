package com.adhanjadevelopers.geofencingdemo

import android.content.Context
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.android.containmentzone.Activity.MapsActivity
import com.android.containmentzone.R
import com.android.containmentzone.Utility.MySingleton
import com.android.containmentzone.Utility.PrefManager
import com.android.volley.AuthFailureError
import com.android.volley.Response
import com.android.volley.VolleyError
import com.android.volley.toolbox.StringRequest
import com.neeloy.lib.data.storage.StorageUtility


private const val NOTIFICATION_ID = 33
private const val CHANNEL_ID = "GeofenceChannel"

fun createChannel(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val notificationChannel =
            NotificationChannel(CHANNEL_ID, "Channel1", NotificationManager.IMPORTANCE_HIGH)
        val notificationManager = context.getSystemService(NotificationManager::class.java)
        notificationManager.createNotificationChannel(notificationChannel)
    }
}

fun NotificationManager.sendGeofenceEnteredNotification(context: Context) {

    //Opening the Notification
    val contentIntent = Intent(context, MapsActivity::class.java)
    val contentPendingIntent = PendingIntent.getActivity(
        context,
        NOTIFICATION_ID,
        contentIntent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    //Building the notification
    val builder = NotificationCompat.Builder(context, CHANNEL_ID)
        .setContentTitle(context.getString(R.string.app_name))
        .setContentText("You have entered a containment zone")
        .setSmallIcon(R.mipmap.ic_launcher_round)
        .setPriority(NotificationCompat.PRIORITY_HIGH)
        .setContentIntent(contentPendingIntent)
        .build()

    _sendMAail(context)

    this.notify(NOTIFICATION_ID, builder)
}

fun _sendMAail(context: Context) {
    val stringRequest: StringRequest = object : StringRequest(Method.POST, PrefManager._SEND_MAIL,
        Response.Listener { response: String ->
            Log.e("Send mail : ", response)
            if (response.equals("Mail sent successfully!")) {
                StorageUtility.setStringData(PrefManager.LAT_LON, "")
            } else {
                Log.e("Error", response)
            }
        },
        Response.ErrorListener { error: VolleyError ->
            Log.d("Send mail: ", error.toString())
        }) {
        @Throws(AuthFailureError::class)
        override fun getParams(): Map<String, String> {
            val map = HashMap<String, String>()
            map["email"] = StorageUtility.getStringData(PrefManager.MAIL)
            return map
        }
    }
    MySingleton.getInstance(context)!!.addToRequestQueue(stringRequest, PrefManager._SEND_MAIL)
}
