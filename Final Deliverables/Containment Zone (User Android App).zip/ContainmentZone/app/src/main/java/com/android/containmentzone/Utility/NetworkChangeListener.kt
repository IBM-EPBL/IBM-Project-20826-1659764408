package com.android.containmentzone.Utility

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.AppCompatButton
import com.android.containmentzone.R

class NetworkChangeListener : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (!CheckInternet.isConnected(context)) {
            val builder = AlertDialog.Builder(context)
            val layout_dialog: View =
                LayoutInflater.from(context).inflate(R.layout.layout_check_internet, null)
            builder.setView(layout_dialog)
            val btnRetry: AppCompatButton =
                layout_dialog.findViewById<AppCompatButton>(R.id.btnRetry)
            val dialog = builder.create()
            dialog.setCancelable(false)
            dialog.window!!.setGravity(Gravity.CENTER)
            dialog.show()
            dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.window!!.setDimAmount(0.8f)
            builder.setCancelable(false)
            btnRetry.setOnClickListener(View.OnClickListener { v: View? ->
                dialog.dismiss()
                onReceive(context, intent)
            })
        }
    }
}