package com.android.containmentzone.Activity

import android.content.Context
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.telephony.TelephonyManager
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.containmentzone.Utility.MyLoader
import com.android.containmentzone.Utility.MySingleton.Companion.getInstance
import com.android.containmentzone.Utility.PrefManager
import com.android.containmentzone.databinding.ActivityRegistrationBinding
import com.android.volley.AuthFailureError
import com.android.volley.Response
import com.android.volley.VolleyError
import com.android.volley.toolbox.StringRequest


class RegistrationActivity : AppCompatActivity() {

    var registrationBinding: ActivityRegistrationBinding? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        registrationBinding = ActivityRegistrationBinding.inflate(
            layoutInflater)
        setContentView(registrationBinding!!.root)

        val device_id = getImei()
        Log.e("Imei", device_id)

        registrationBinding!!.alReg.setOnClickListener { v: View? ->
            val email = registrationBinding!!.alEmail.text.toString()
            val password = registrationBinding!!.alPassword.text.toString()
            if (email.isEmpty()) Toast.makeText(this, "Enter Email", Toast.LENGTH_SHORT)
                .show()
            else if (password.isEmpty()) Toast.makeText(this,
                "Enter Password",
                Toast.LENGTH_SHORT).show()
            else if (device_id.isEmpty()) Toast.makeText(this,
                "Please check permission for IMEI",
                Toast.LENGTH_SHORT).show()
            else
                _registerUser(email, password, device_id)
        }

        registrationBinding!!.alLogin.setOnClickListener { v: View? -> finish() }
    }

    fun getImei(): String {
        val deviceId: String
        deviceId = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID)
        } else {
            val mTelephony = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            if (mTelephony.deviceId != null) {
                mTelephony.deviceId
            } else {
                Settings.Secure.getString(
                    getContentResolver(),
                    Settings.Secure.ANDROID_ID)
            }
        }
        return deviceId
    }

    private fun _registerUser(email: String, password: String, device_id: String) {
        val myLoader = MyLoader(this)
        myLoader.showIndeterminantLoader("Registering")
        val stringRequest: StringRequest =
            object : StringRequest(Method.POST, PrefManager._REGISTER,
                Response.Listener { response: String ->
                    Log.d("User Register : ", response)
                    if (response == "Registered successfully !") {
                        finish()
                        Toast.makeText(this, "Registered successfully", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, response + "", Toast.LENGTH_SHORT).show()
                    }
                    myLoader.cancelIndeterminantLoader()
                },
                Response.ErrorListener { error: VolleyError? -> myLoader.cancelIndeterminantLoader() }) {
                @Throws(AuthFailureError::class)
                override fun getParams(): Map<String, String>? {
                    val map = HashMap<String, String>()
                    map["email"] = email
                    map["password"] = password
                    map["imei"] = device_id
                    return map
                }
            }
        getInstance(this)!!.addToRequestQueue(stringRequest, PrefManager._REGISTER)
    }
}