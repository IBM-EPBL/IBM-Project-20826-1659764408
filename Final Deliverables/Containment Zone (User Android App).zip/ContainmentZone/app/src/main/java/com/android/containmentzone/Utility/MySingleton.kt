package com.android.containmentzone.Utility

import android.content.Context
import android.graphics.Bitmap
import android.util.LruCache
import com.android.volley.DefaultRetryPolicy
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.toolbox.ImageLoader
import com.android.volley.toolbox.Volley

class MySingleton private constructor(private var mContext: Context) {
    private var mRequestQueue: RequestQueue?
    val imageLoader: ImageLoader

    // getApplicationContext() is key, it keeps you from leaking the
    // Activity or BroadcastReceiver if someone passes one in.
    val requestQueue: RequestQueue
        get() {
            if (mRequestQueue == null) {
                // getApplicationContext() is key, it keeps you from leaking the
                // Activity or BroadcastReceiver if someone passes one in.
                mRequestQueue = Volley.newRequestQueue(mContext.getApplicationContext())
            }
            return mRequestQueue!!
        }

    fun <T> addToRequestQueue(req: Request<T>, tag: String?) {
        req.tag = tag
        req.retryPolicy = DefaultRetryPolicy(30000,
            DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
            DefaultRetryPolicy.DEFAULT_BACKOFF_MULT)
        requestQueue.add(req)
    }

    fun cancelPendingRequests(tag: Any?) {
        if (mRequestQueue != null) {
            mRequestQueue!!.cancelAll(tag)
        }
    }

    companion object {
        private var mHomeworkSingletonInstance: MySingleton? = null

        @JvmStatic
        @Synchronized
        fun getInstance(context: Context): MySingleton? {
            if (mHomeworkSingletonInstance == null) {
                mHomeworkSingletonInstance = MySingleton(context)
            }
            return mHomeworkSingletonInstance
        }
    }

    init {
        mRequestQueue = requestQueue
        imageLoader = ImageLoader(mRequestQueue,
            object : ImageLoader.ImageCache {
                private val cache = LruCache<String, Bitmap>(20)
                override fun getBitmap(url: String): Bitmap? {
                    return cache[url]
                }

                override fun putBitmap(url: String, bitmap: Bitmap) {
                    cache.put(url, bitmap)
                }
            })
    }

}