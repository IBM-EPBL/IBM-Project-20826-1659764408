package com.android.containmentzone.Utility

object PrefManager {
    var USER_LOGIN_STATUS = "login_status" //If logged in 1 / else 0
    var MAIL = "mail" //If logged in 1 / else 0
    var LAT_LON = "lat_lon"

    //--------------------PROD------------------------//
    //Enable crashlytics from build.gradle
    var BASE_URL = "http://192.168.0.103:5000/"

    //API Variables
    var _LOGIN = BASE_URL + "login"
    var _REGISTER = BASE_URL + "register"
    var _GET_ZONES = BASE_URL + "getzones"
    var _SEND_MAIL = BASE_URL + "sendmail"
}