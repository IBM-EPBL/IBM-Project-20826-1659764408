from flask import Flask, render_template, request, redirect, url_for
import ibm_db
app = Flask(__name__, template_folder='templates', static_folder='static')

conn = ibm_db.connect("DATABASE=bludb;HOSTNAME=b0aebb68-94fa-46ec-a1fc-1c999edb6187.c3n41cmd0nqnrk39u98g.databases.appdomain.cloud;PORT=31249;SECURITY=SSL;SSLServerCertificate:DigiCertGlobalRootCA;UID=gyj23042;PWD=a5CFymQzrGXGeOnC;", "", "")

@app.route('/')
def html():
    return render_template('login.html')
    
@app.route('/logout')
def logout():
    return render_template('login.html')

@app.route('/seezones')
def seezones():
    msg = ''
    sql = "SELECT * FROM zones"
    results = []
    stmt = ibm_db.exec_immediate(conn, sql)
    row_dict = ibm_db.fetch_both(stmt)
    cols = ibm_db.num_fields(stmt)
    
    while ( row_dict ):
         results.append(row_dict)

         row_dict = ibm_db.fetch_both(stmt)
    print(results)
    if(stmt):
        msg = 'Zones getted successfully !'
        return render_template('/zoneslist.html', zones = results )
    else:
        msg = 'Unable to get zones !'
        return render_template('/addzone.html', msg = msg)

@app.route('/login',methods =['POST'])
def login():
    msg = ''
    if request.method == 'POST' :
        email = request.form.get('email')
        password = request.form.get('password')
        sql = "SELECT * FROM admins WHERE email =? AND password=?"
        stmt = ibm_db.prepare(conn, sql)
        ibm_db.bind_param(stmt,1,email)
        ibm_db.bind_param(stmt,2,password)
        ibm_db.execute(stmt)
        account = ibm_db.fetch_assoc(stmt)
        print (account)
        if account:
            msg = 'Logged in successfully !'
            return render_template('/addzone.html', msg = msg)
        else:
            msg = 'Incorrect username / password !'
            return render_template('/login.html', msg = msg)

@app.route('/addzone', methods =['POST'])
def addzone():
    msg = ''
    if request.method == 'POST' :
        area = request.form.get('area')
        latlon = request.form.get('latlon')
        type = request.form.get('type')
        insert_sql = "INSERT INTO zones VALUES (?, ?, ?)"
        prep_stmt = ibm_db.prepare(conn, insert_sql)
        ibm_db.bind_param(prep_stmt, 1, area)
        ibm_db.bind_param(prep_stmt, 2, latlon)
        ibm_db.bind_param(prep_stmt, 3, type)
        ibm_db.execute(prep_stmt)
        msg = 'You have successfully registered !'
    return render_template('/addzone.html', msg = msg)

if __name__ == '__main__':
    app.run(host='0.0.0.0',debug=True)
