from flask import Flask, render_template, request, redirect, url_for, jsonify
import ibm_db
import smtplib
import sendgrid
import os
from sendgrid.helpers.mail import Mail, Email, To, Content
app = Flask(__name__)

conn = ibm_db.connect("DATABASE=bludb;HOSTNAME=b0aebb68-94fa-46ec-a1fc-1c999edb6187.c3n41cmd0nqnrk39u98g.databases.appdomain.cloud;PORT=31249;SECURITY=SSL;SSLServerCertificate:DigiCertGlobalRootCA;UID=gyj23042;PWD=a5CFymQzrGXGeOnC;", "", "")

@app.route('/register',methods =['POST'])
def register():
    email = request.form.get("email")
    password = request.form.get("password")
    imei = request.form.get("imei")
    sql = "SELECT * FROM users WHERE email =?"
    stmt = ibm_db.prepare(conn, sql)
    ibm_db.bind_param(stmt,1,email)
    ibm_db.execute(stmt)
    account = ibm_db.fetch_assoc(stmt)
    if account:
        msg = 'Account already exists !'
        return msg
    else:
        sql = "INSERT INTO users (email, password, imei) VALUES (?,?,?)"
        prep_stmt = ibm_db.prepare(conn, sql)
        ibm_db.bind_param(prep_stmt, 1, email)
        ibm_db.bind_param(prep_stmt, 2, password)
        ibm_db.bind_param(prep_stmt, 3, imei)
        ibm_db.execute(prep_stmt)
        msg = 'Registered successfully !'
        return msg

    
@app.route('/login',methods =['POST'])
def login():
    email = request.form.get("email")
    password = request.form.get("password")
    sql = "SELECT * FROM users WHERE email =? AND password=?"
    stmt = ibm_db.prepare(conn, sql)
    ibm_db.bind_param(stmt, 1, email)
    ibm_db.bind_param(stmt, 2, password)
    ibm_db.execute(stmt)
    account = ibm_db.fetch_assoc(stmt)
    if account:
        msg = 'Logged in successfully !'
        return msg
    else:
        msg = 'Incorrect username / password !'
        return msg

@app.route('/getzones',methods =['GET'])
def seezones():
    msg = ''
    sql = "SELECT latlon FROM zones"
    results = []
    stmt = ibm_db.exec_immediate(conn, sql)
    row_dict = ibm_db.fetch_both(stmt)
    cols = ibm_db.num_fields(stmt)
    
    while ( row_dict ):
         results.append(row_dict)

         row_dict = ibm_db.fetch_both(stmt)
    print(results)
    if(stmt):
        return str(results)
    else:
        msg = 'Unable to get zones !'
        return msg

@app.route('/sendmail',methods =['POST'])
def sendgridmail():
    email = request.form.get("email")
    sg = sendgrid.SendGridAPIClient('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')
    from_email = Email("rdk711119104020@jit.ac.in")  # Change to your verified sender
    to_email = To(email)  # Change to your recipient
    subject = "Alert from containment zone"
    content = Content("text/plain","Hi,/n You  have entered into containment zone.Be safe.")
    mail = Mail(from_email, to_email, subject, content)

    # Get a JSON-ready representation of the Mail object
    mail_json = mail.get()
    # Send an HTTP POST request to /mail/send
    response = sg.client.mail.send.post(request_body=mail_json)
    msg = 'Mail sent successfully!'
    return msg

if __name__ == '__main__':
    app.run(host='0.0.0.0',debug=True)
